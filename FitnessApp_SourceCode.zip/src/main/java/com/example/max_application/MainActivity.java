package com.example.max_application;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;

import com.example.max_application.model.AccountCreationManager;
import com.example.max_application.model.LoginManager;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private Button createAccountButton;
    private LoginManager loginManager;
    private AccountCreationManager accountManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginManager = new LoginManager(this);
        accountManager = new AccountCreationManager(this);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(v -> loginManager.loginUser(usernameInput.getText().toString(), passwordInput.getText().toString()));

        createAccountButton = findViewById(R.id.createAccountButton);
        findViewById(R.id.createAccountButton).setOnClickListener(v -> {
            Intent intent = new Intent(this, AccountCreationActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        loginManager.cleanUp();
        accountManager.cleanUp();
    }
}