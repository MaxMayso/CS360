package com.example.max_application.model;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.example.max_application.DatabaseHelper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AccountCreationManager {
    private Context context;
    private DatabaseHelper dbHelper;
    private ExecutorService executorService;

    public AccountCreationManager(Context context) {
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public interface CreationCallback {
        void onSuccess();
        void onFailure(String message);
    }

    public void createNewUser(String username, String password, CreationCallback callback) {
        executorService.execute(() -> {
            if (!dbHelper.checkUser(username, password)) {
                dbHelper.addUser(username, password);
                callback.onSuccess();
            } else {
                new Handler(Looper.getMainLooper()).post(() -> callback.onFailure("User already exists"));
            }
        });
    }

    public void cleanUp() {
        if (!executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}