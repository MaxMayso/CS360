package com.example.max_application.model;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;

import com.example.max_application.DatabaseHelper;
import com.example.max_application.DataDisplayActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginManager {
    private Activity activity;
    private DatabaseHelper dbHelper;
    private ExecutorService executorService;

    public LoginManager(Activity activity) {
        this.activity = activity;
        this.dbHelper = new DatabaseHelper(activity);
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public void loginUser(String username, String password) {
        executorService.execute(() -> {
            if (dbHelper.checkUser(username, password)) {
                activity.runOnUiThread(() -> {
                    // Start DataDisplayActivity upon successful login
                    Intent intent = new Intent(activity, DataDisplayActivity.class);
                    activity.startActivity(intent);
                    activity.finish(); // Optionally close the current activity
                });
            } else {
                activity.runOnUiThread(() ->
                        Toast.makeText(activity, "Login failed. Incorrect username or password.", Toast.LENGTH_LONG).show()
                );
            }
        });
    }

    public void cleanUp() {
        if (!executorService.isShutdown()) {
            executorService.shutdown();
        }
    }
}