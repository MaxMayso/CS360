package com.example.max_application;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.max_application.model.AccountCreationManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class AccountCreationActivity extends AppCompatActivity {
    private AccountCreationManager accountManager;
    private EditText usernameEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        findViewById(R.id.createAccountButton).setOnClickListener(v -> createAccount());

        accountManager = new AccountCreationManager(this);
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        FloatingActionButton fabUserExists = findViewById(R.id.fabUserExists);

        accountManager.createNewUser(username, password, new AccountCreationManager.CreationCallback() {
            @Override
            public void onSuccess() {
                runOnUiThread(() -> {
                    Toast.makeText(AccountCreationActivity.this, "User created successfully!", Toast.LENGTH_LONG).show();
                    finish();  // Close this activity and return
                });
            }

            @Override
            public void onFailure(String message) {
                runOnUiThread(() -> Toast.makeText(AccountCreationActivity.this, message, Toast.LENGTH_LONG).show());
                fabUserExists.setVisibility(View.VISIBLE); // Show the FAB
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        accountManager.cleanUp();
    }
}