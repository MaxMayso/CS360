package com.example.max_application;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {
    private DataAdapter dataAdapter;
    private RecyclerView recyclerView;
    private SwitchMaterial switchSMSNotification;
    private boolean isSMSNotificationEnabled = false;
    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize the data list and setup the RecyclerView
        List<Item> items = new ArrayList<>();
        dataAdapter = new DataAdapter(this, items);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(dataAdapter);

        // Setup the FloatingActionButton to add new items
        FloatingActionButton fabAddItem = findViewById(R.id.fabAddItem);
        fabAddItem.setOnClickListener(view -> showAddItemDialog());

        // Initialize the switch and permission launcher
        switchSMSNotification = findViewById(R.id.switchSMSNotification);
        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                switchSMSNotification.setChecked(false);
            }
        });

        // Setup switch change listener
        switchSMSNotification.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                requestSMSPermission();
            } else {
                Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
        } else {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void showAddItemDialog() {
        // Inflate the custom layout for the dialog
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.dialog_add_item, null);
        EditText editWeight = view.findViewById(R.id.editWeight);
        EditText editDate = view.findViewById(R.id.editDate);

        // Build and show the dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item")
                .setView(view)
                .setPositiveButton("Add", (dialog, which) -> {
                    try {
                        double weight = Double.parseDouble(editWeight.getText().toString().trim());
                        String date = editDate.getText().toString().trim();
                        Item newItem = new Item(date, weight);
                        dataAdapter.addItem(newItem);

                        if (isSMSNotificationEnabled) {
                            SendSMSNotification.sendSMS(this, "(800)555-2000", "New item added: Date - " + date + ", Weight - " + weight + " lbs");
                        }
                    } catch (NumberFormatException e) {
                        e.printStackTrace(); // Log or handle the parse error
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }
}