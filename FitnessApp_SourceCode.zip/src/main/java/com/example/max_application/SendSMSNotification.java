package com.example.max_application;

import android.content.Context;
import android.telephony.SmsManager;
import android.widget.Toast;

public class SendSMSNotification {

    public static void sendSMS(Context context, String phoneNumber, String message) {
        try {
            SmsManager smsManager = context.getSystemService(SmsManager.class);
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(context, "SMS failed, please try again.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}