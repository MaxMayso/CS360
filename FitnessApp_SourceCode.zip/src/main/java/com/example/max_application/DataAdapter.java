package com.example.max_application;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private List<Item> mData;
    private LayoutInflater mInflater;
    private DatabaseHelper dbHelper;

    // Constructor adjusted for List<Item>
    DataAdapter(Context context, List<Item> data) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
        this.dbHelper = new DatabaseHelper(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item currentItem = mData.get(position);
        holder.tvItemData.setText("Date: " + currentItem.getDate() + ", Weight: " + currentItem.getWeight() + " lbs");
        holder.btnDelete.setOnClickListener(v -> deleteItem(currentItem, position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    private void deleteItem(Item item, int position) {
        dbHelper.deleteItem(item.getDate());
        mData.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mData.size());
    }

    public void addItem(Item item) {
        if (mData != null) {
            mData.add(item);
            notifyItemInserted(mData.size() - 1);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvItemData;
        Button btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvItemData = itemView.findViewById(R.id.tvItemData);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}