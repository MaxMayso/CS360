package com.example.max_application;

public class Item {
    private String date;
    private double weight;

    public Item(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }
}